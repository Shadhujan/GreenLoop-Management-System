# GreenLoop Management System - Final Diagrams

These diagrams are based on the implemented GreenLoop Management System scope:

- Product Catalogue Management
- Client Management
- Stock / Inventory Management
- Low Stock Checking
- Java Swing desktop UI
- MongoDB database collections

---

## Figure 1: Use Case Diagram for GreenLoop Management System

```mermaid
flowchart LR
    Staff([Staff / Admin])

    subgraph GreenLoop_System[GreenLoop Management System]
        UC_Products((Manage Products))
        UC_AddProduct((Add Product))
        UC_UpdateProduct((Update Product))
        UC_DeleteProduct((Delete Product))
        UC_SearchProduct((Search Product))
        UC_ViewProduct((View Products))

        UC_Clients((Manage Clients))
        UC_AddClient((Add Client))
        UC_UpdateClient((Update Client))
        UC_DeleteClient((Delete Client))
        UC_SearchClient((Search Client))
        UC_ViewClient((View Clients))

        UC_Inventory((Manage Inventory))
        UC_AddStock((Add Stock))
        UC_UpdateStock((Update Stock))
        UC_DeleteStock((Delete Stock))
        UC_SearchStock((Search Stock))
        UC_ViewStock((View Inventory))
        UC_LowStock((Check Low Stock))
    end

    Staff --> UC_Products
    Staff --> UC_Clients
    Staff --> UC_Inventory
    Staff --> UC_LowStock

    UC_Products -. include .-> UC_AddProduct
    UC_Products -. include .-> UC_UpdateProduct
    UC_Products -. include .-> UC_DeleteProduct
    UC_Products -. include .-> UC_SearchProduct
    UC_Products -. include .-> UC_ViewProduct

    UC_Clients -. include .-> UC_AddClient
    UC_Clients -. include .-> UC_UpdateClient
    UC_Clients -. include .-> UC_DeleteClient
    UC_Clients -. include .-> UC_SearchClient
    UC_Clients -. include .-> UC_ViewClient

    UC_Inventory -. include .-> UC_AddStock
    UC_Inventory -. include .-> UC_UpdateStock
    UC_Inventory -. include .-> UC_DeleteStock
    UC_Inventory -. include .-> UC_SearchStock
    UC_Inventory -. include .-> UC_ViewStock
    UC_Inventory -. include .-> UC_LowStock
```

---

## Figure 2: Class Diagram for Implemented Java Swing Application

```mermaid
classDiagram
    class Main {
        +main(String[] args) void
    }

    class DashboardFrame {
        -Color DARK_GREEN
        -Color LIGHT_GREEN
        +DashboardFrame()
        -createTabbedPanel() JTabbedPane
    }

    class ProductPanel {
        -JTextField txtProductId
        -JTextField txtProductName
        -JTextField txtCategory
        -JTextField txtPrice
        -JComboBox~String~ cmbEcoRating
        -JTextArea txtDescription
        -JTable productTable
        -DefaultTableModel tableModel
        -ProductDAO productDAO
        +ProductPanel()
        -addProduct() void
        -updateProduct() void
        -deleteProduct() void
        -searchProduct() void
        -loadProducts() void
        -loadTable(List~Product~ products) void
        -getProductFromForm() Product
        -fillFormFromSelectedRow() void
        -clearForm() void
    }

    class ClientPanel {
        -JTextField txtClientId
        -JTextField txtClientName
        -JTextField txtBusinessName
        -JTextField txtPhone
        -JTextField txtEmail
        -JTextArea txtAddress
        -JTable clientTable
        -DefaultTableModel tableModel
        -ClientDAO clientDAO
        +ClientPanel()
        -addClient() void
        -updateClient() void
        -deleteClient() void
        -searchClient() void
        -loadClients() void
        -loadTable(List~Client~ clients) void
        -getClientFromForm() Client
        -fillFormFromSelectedRow() void
        -clearForm() void
    }

    class InventoryPanel {
        -JTextField txtInventoryId
        -JTextField txtProductName
        -JTextField txtQuantity
        -JTextField txtReorderLevel
        -JTextField txtSupplierName
        -JTable inventoryTable
        -DefaultTableModel tableModel
        -InventoryDAO inventoryDAO
        +InventoryPanel()
        -addInventory() void
        -updateInventory() void
        -deleteInventory() void
        -searchInventory() void
        -checkLowStock() void
        -loadInventory() void
        -loadTable(List~Inventory~ inventoryList) void
        -getInventoryFromForm() Inventory
        -fillFormFromSelectedRow() void
        -clearForm() void
    }

    class MongoConnection {
        -String CONNECTION_STRING
        -String DATABASE_NAME
        -MongoClient mongoClient
        +getDatabase() MongoDatabase
    }

    class Product {
        -String productId
        -String name
        -String category
        -double price
        -int ecoRating
        -String description
        +Product(String productId, String name, String category, double price, int ecoRating, String description)
        +getProductId() String
        +getName() String
        +getCategory() String
        +getPrice() double
        +getEcoRating() int
        +getDescription() String
    }

    class Client {
        -String clientId
        -String clientName
        -String businessName
        -String phone
        -String email
        -String address
        +Client(String clientId, String clientName, String businessName, String phone, String email, String address)
        +getClientId() String
        +getClientName() String
        +getBusinessName() String
        +getPhone() String
        +getEmail() String
        +getAddress() String
    }

    class Inventory {
        -String inventoryId
        -String productName
        -int quantity
        -int reorderLevel
        -String supplierName
        +Inventory(String inventoryId, String productName, int quantity, int reorderLevel, String supplierName)
        +getInventoryId() String
        +getProductName() String
        +getQuantity() int
        +getReorderLevel() int
        +getSupplierName() String
        +getStatus() String
    }

    class ProductDAO {
        -MongoCollection~Document~ collection
        +ProductDAO()
        +addProduct(Product product) void
        +updateProduct(Product product) void
        +deleteProduct(String productId) void
        +getAllProducts() List~Product~
        +searchProducts(String keyword) List~Product~
        +productIdExists(String productId) boolean
        -documentToProduct(Document doc) Product
    }

    class ClientDAO {
        -MongoCollection~Document~ collection
        +ClientDAO()
        +addClient(Client client) void
        +updateClient(Client client) void
        +deleteClient(String clientId) void
        +getAllClients() List~Client~
        +searchClients(String keyword) List~Client~
        +clientIdExists(String clientId) boolean
        -documentToClient(Document doc) Client
    }

    class InventoryDAO {
        -MongoCollection~Document~ collection
        +InventoryDAO()
        +addInventory(Inventory inventory) void
        +updateInventory(Inventory inventory) void
        +deleteInventory(String inventoryId) void
        +getAllInventory() List~Inventory~
        +searchInventory(String keyword) List~Inventory~
        +getLowStockItems() List~Inventory~
        +inventoryIdExists(String inventoryId) boolean
        -documentToInventory(Document doc) Inventory
    }

    Main --> DashboardFrame : opens
    DashboardFrame --> ProductPanel : contains tab
    DashboardFrame --> ClientPanel : contains tab
    DashboardFrame --> InventoryPanel : contains tab

    ProductPanel --> ProductDAO : uses
    ClientPanel --> ClientDAO : uses
    InventoryPanel --> InventoryDAO : uses

    ProductDAO --> MongoConnection : connects
    ClientDAO --> MongoConnection : connects
    InventoryDAO --> MongoConnection : connects

    ProductDAO --> Product : manages
    ClientDAO --> Client : manages
    InventoryDAO --> Inventory : manages
```

---

## Figure 3: ER / MongoDB Collection Diagram for GreenLoop Database

Since this system uses MongoDB, the diagram is shown as a collection diagram instead of a traditional relational ER diagram.

```mermaid
erDiagram
    PRODUCTS {
        ObjectId _id
        string productId
        string name
        string category
        double price
        int ecoRating
        string description
    }

    CLIENTS {
        ObjectId _id
        string clientId
        string clientName
        string businessName
        string phone
        string email
        string address
    }

    INVENTORY {
        ObjectId _id
        string inventoryId
        string productName
        int quantity
        int reorderLevel
        string supplierName
        string status
    }

    PRODUCTS ||--o{ INVENTORY : "tracked by productName"
```

### ER / MongoDB Diagram Note

In the implemented version, the `inventory` collection stores `productName`, not a strict relational foreign key. So the link between `products` and `inventory` is a conceptual relationship. The `clients` collection is independent because order processing is not included in the current implementation.
